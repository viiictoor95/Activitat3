<?php

	namespace X\Sys;

	class Model{

		public function __construct($array=null){
			
		}
	}