<?php
	namespace X\Sys;

	use X\Sys\Registry;
	 //Permet la connexió entre vista i controlador, i entre model i controlador
	
	class Controller{
		protected $model;
		protected $view;
		protected $params;
		protected $dataView=array();// Envia la data a les vistes
		protected $conf; 
		protected $app; 
		
		function __construct($params=null,$dataView=null){
			$this->params=$params;
			$this->conf=Registry::getInstance();
			$this->app=(array)$this->conf->app;
			$this->addData($this->app);
			
		}
	
		protected function addData($array){
			if(is_array($array) && is_array($this->dataView)){
				$this->dataView=array_merge($this->dataView,$array); //si els dos son arrays, els combina en un sol (dataView)
			}else{
				$this->dataView=$array;
			}

		}
		function error(){
            $this->msg='Error. Action not defined'; //guarda l'error per enviarse'l al template
         }
		
		function ajax($output){
			ob_clean();
			if(is_array($output)){
				echo json_encode($output);
			}
		}

	}