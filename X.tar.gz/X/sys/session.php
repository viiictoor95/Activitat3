<?php
	namespace X\Sys;
	
	class Session{

		static function init(){ //inicia la sessió
			session_start();
			self::set('id',session_id());
				//guarda la session_id en l'id
		}

		static function set($key,$value){ //crea la clau de la sessió
			$_SESSION[$key]=$value;
		}

		static function get($key){ //recull la clau de la sessió
			if(self::exist($key)){
				return $_SESSION[$key];
			}
			else{
				return null;
			}
		}

		static function exist($key){ //comprova si existeix la clau
			if(array_key_exists($key, $_SESSION)){
				return true;
			}else{
				return false;
			}
		}
		static function del($key){  //si existeix la clau la elimina
			if (self::exist($key)){
				unset($_SESSION[$key]);
			}
		}

		static function destroy(){
			session_destroy();//tanca la sessió
		}
	}