<?php   //incloïm el head i footer per a mostrar-ho
	include 'head_common.php';
	?>
<body><!--El body el tanquem al footer-->
	<h1><?= $this->page; ?></h1>
	
<?php 
	include 'footer_common.php';
?>