<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title><?= $this->page;?></title>
	<link rel="stylesheet" href="<?= APP_W.'pub/css/bootstrap.min.css'; ?>">
</head>