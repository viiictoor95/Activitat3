<footer>
	<?= $this->version; ?>
	<?= $this->title; ?>
	<?php if(isset($this->msg)){
		echo $this->msg;  //el missatge el rep del controlador
	}?>

</footer>
</body>
</html>