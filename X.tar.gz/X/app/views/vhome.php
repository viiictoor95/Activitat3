<?php

	namespace X\App\Views;

	use \X\Sys\View;
	
	class vHome extends View{

		function __construct($dataView){
			
			parent::__construct($dataView); //rep el dataView del controlador
			echo $this->render('thome.php'); //carrega thome
		}
	}