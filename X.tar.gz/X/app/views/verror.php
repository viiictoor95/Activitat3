<?php

	namespace X\App\Views;

	use \X\Sys\View;
	
//Vista d'errors

	class vError extends View{

		function __construct($dataView){
			
			parent::__construct($dataView); //rep el dataView del controlador
			echo $this->render('terror.php'); //carrega terror
		}
	}