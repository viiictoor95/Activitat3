<?php

	namespace X\App\Views;

	use \X\Sys\View;
	
	class vUsers extends View{

		function __construct($dataView){
			parent::__construct($dataView); //rep el dataView del controlador
			echo $this->render('tusers.php'); //carrega tusers
		}
	}