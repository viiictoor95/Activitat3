<?php

   namespace X\App\Controllers;

   use X\Sys\Controller;

//Controlador Home
   class Home extends Controller{
   		

   		public function __construct($params){
   			parent::__construct($params);
            $this->addData(array(
               'page'=>'Home'));
            //crea models i vistes dels errors

   			$this->model=new \X\App\Models\mHome();
   			$this->view =new \X\App\Views\vHome($this->dataView);
            
   		}


   		function home(){
   			
   		}

         
   }
