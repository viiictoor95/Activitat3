<?php

   namespace X\App\Controllers;

   use X\Sys\Controller;

   //Controlador d'errors

   class Error extends Controller{
   		

   		public function __construct($params){
   			parent::__construct($params);
            $this->addData(array(
               'page'=>'Error'));
            
            //crea models i vistes dels errors

   			$this->model=new \X\App\Models\mError();
   			$this->view =new \X\App\Views\vError($this->dataView); 
            
   		}


   		function home(){
   			
   		}
   }
